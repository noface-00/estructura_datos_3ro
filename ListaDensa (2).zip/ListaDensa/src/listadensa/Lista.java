/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package listadensa;

public interface Lista {
    void insertar(int elemento);
    boolean eliminar(int elemento);
    boolean buscar(int elemento);
    void recorrer();
}

