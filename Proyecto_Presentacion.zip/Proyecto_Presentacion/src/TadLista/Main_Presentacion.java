/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TadLista;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author lvsld
 */
public class Main_Presentacion {

    public static boolean bandera = true;

    public static void main(String[] args) throws NumberFormatException, IOException {
        TadLista lista = new TadLista();
        int deter, aux, valor, posicion,buscar,eliminar;

        BufferedReader linea = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Ingrese la dimension de la Lista y sus Valores");
        lista.cargarTadLista();

        while (bandera == true) {
            System.out.println("Seleccione la opcion a ejecutar\n" + "1.-Buscar un elemento\n"
                    + "2.-Insertar un Elemento\n" + "3.-Eliminar un Elemento\n" + "4.-Recorrido completo\n"
                    + "5.-Salir");
            deter = Integer.parseInt(linea.readLine());

            switch (deter) {
                case 1:
                    System.out.println("Ingrese el Valor a Buscar");
                    buscar=Integer.parseInt(linea.readLine());
                    lista.buscarelemento(buscar);
                    lista.imprimirLista();
                    break;
                case 2:
                    System.out.println("Ingrese el elemento a insertar");
                    valor = Integer.parseInt(linea.readLine());
                    System.out.println("Ingrese la posicion a ingresar");
                    posicion= Integer.parseInt(linea.readLine());
                    lista.insertarEnPosicion(valor, posicion);
                    lista.imprimirLista();
                    break;
                case 3:
                    System.out.println("Ingrese el elemento a eliminar");
                    eliminar=Integer.parseInt(linea.readLine());
                    lista.eliminarValor(eliminar);
                    lista.imprimirLista();
                    break;
                case 4:
                    lista.contar();
                    lista.imprimirLista();
                    break;
                case 5:
                    bandera = false;
                    break;
            }
        }
    }
}
